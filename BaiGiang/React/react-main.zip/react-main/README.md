# React Examples

Các ví dụ hoặc project nhỏ sử dụng trong khóa học ReactJS

# React Devtools trên Safari hoặc React Native

💡 Nguồn: [https://www.npmjs.com/package/react-devtools](https://www.npmjs.com/package/react-devtools)

Cài đặt `react-devtools`

```
npm i -g react-devtools
```

Khởi động `react-devtools`

```
react-devtools
```

Thêm script kết nối tới React Devtools trong HTML

```html
<head>
    <!-- XÓA SCRIPT KHI BUILD PRODUCTION -->
    <script src="http://localhost:8097"></script>
</head>
```
